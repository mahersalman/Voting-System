document.addEventListener("DOMContentLoaded", function () {
    let votesForMow = 0;
    let votesForJane = 0;
    let hasVoted = false;
    let full_name = '';
    let ID = '';

    // Always show the exit button initially
    document.getElementById('back').classList.remove('hidden'); // Ensure exit button is visible

    // Registration Section
    document.getElementById('registerButton').addEventListener('click', function () {
        full_name = document.getElementById('full_name').value.trim();
        ID = document.getElementById('ID').value.trim();

        if (full_name) {
            // Hide registration section and show voting section
            document.getElementById('registrationSection').classList.add('hidden');
            document.getElementById('votingSection').classList.remove('hidden');
        } else {
            // Show SweetAlert if the user doesn't enter a name
            swal("Oops!", "Please enter your ID to register.", "error");
        }
    });

    // Voting Section
    document.getElementById('voteButton').addEventListener('click', function () {
        handleVote('Mow');
    });

    document.getElementById('voteButton2').addEventListener('click', function () {
        handleVote('Jane');
    });

    // Handle the voting logic
    function handleVote(candidate) {
        if (hasVoted) {
            swal("Oops!", "You've already voted!", "warning");
        } else {
            if (candidate === 'Mow') {
                votesForMow++;
            } else if (candidate === 'Jane') {
                votesForJane++;
            }
            hasVoted = true;
            showThankYouModal(); // Show Thank You Modal
        }
    }

    // Thank You Modal
    function showThankYouModal() {
        swal({
            title: `Thank you, ${full_name}!`,
            text: "Your vote has been recorded.",
            icon: "success",
            button: "Close",
        });
    }

    // Show Vote Results
    function showResults() {
        document.getElementById('votingSection').classList.add('hidden'); // Hide voting section
        const resultSection = document.getElementById('resultSection');
        resultSection.classList.remove('hidden'); // Show result section

        const resultMessage = document.getElementById('resultMessage');
        resultMessage.textContent = `Results: Mow (${votesForMow}) vs Jane (${votesForJane})`;
    }

    // Exit Section - This is where the exit functionality works
    document.getElementById('exit').addEventListener('click', function () {
        // Hide voting section, result section, and back section, show registration section
        document.getElementById('votingSection').classList.add('hidden');
        document.getElementById('resultSection').classList.add('hidden');
        document.getElementById('registrationSection').classList.remove('hidden');
    });
});
